@echo off
echo ================================
echo GitHub Deployment Script
echo ================================
echo.

REM Check if git is installed
git --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Git is not installed!
    echo Please install Git from: https://git-scm.com/download/win
    pause
    exit /b 1
)

echo Git is installed. Proceeding...
echo.

REM Get GitHub repository URL from user
set /p REPO_URL="Enter your GitHub repository URL (e.g., https://github.com/username/investigation-platform.git): "

echo.
echo Initializing git repository...
git init

echo Adding files...
git add .

echo Committing files...
git commit -m "Initial commit - Investigation Platform Prototype"

echo Adding remote repository...
git remote add origin %REPO_URL%

echo Pushing to GitHub...
git branch -M main
git push -u origin main

echo.
echo ================================
echo ✅ Deployment Complete!
echo ================================
echo.
echo Your prototype is now on GitHub!
echo.
echo To enable GitHub Pages:
echo 1. Go to your repository on GitHub
echo 2. Click Settings
echo 3. Click Pages (left sidebar)
echo 4. Under "Source", select "main" branch
echo 5. Click Save
echo 6. Wait 1-2 minutes
echo 7. Your site will be live at: https://username.github.io/investigation-platform/
echo.
pause
