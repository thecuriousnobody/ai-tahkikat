# 🔍 Investigation Platform - Complete Prototype

## Overview
Complete Investigation Report Automation Platform with multi-tier architecture.

## Features
- ✅ Client Portal (Department User + Dashboard)
- ✅ Admin Panel (Platform Management)
- ✅ Billing Module
- ✅ Multi-client Support
- ✅ Export to Excel & PowerPoint
- ✅ Case Management Workflow
- ✅ Real-time Dashboard

## How to Use
1. Open `index.html` in any modern browser (Chrome, Edge, Firefox)
2. Choose your role:
   - **Client Portal** → Department User or Client Dashboard
   - **Admin Panel** → Platform management
3. All data is stored in browser memory (resets on refresh)

## Live Demo
[View Live Demo](https://your-username.github.io/investigation-platform/)

## Technology
- Pure HTML/CSS/JavaScript
- Font Awesome Icons
- XLSX.js for Excel export
- PptxGenJS for PowerPoint export
- No backend required (frontend prototype)

## License
Proprietary - All rights reserved

## Contact
For questions or feedback, please open an issue.
