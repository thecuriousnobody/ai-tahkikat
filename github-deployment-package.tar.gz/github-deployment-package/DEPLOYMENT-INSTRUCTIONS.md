# 📦 Deployment Instructions

## Quick Start (5 Minutes)

### For Windows Users:

1. **Open Command Prompt in this folder**
   - Right-click on the `github-deployment-package` folder
   - Choose "Open in Terminal" or "Open Command Prompt here"

2. **Run the deployment script**
   ```cmd
   deploy-windows.bat
   ```

3. **When prompted, paste your GitHub repository URL**
   - Example: `https://github.com/yourusername/investigation-platform.git`
   - Get this from your GitHub repository page (green "Code" button)

4. **Wait for upload to complete**

5. **Enable GitHub Pages**
   - Go to your repo on GitHub.com
   - Settings → Pages
   - Source: main branch
   - Save
   - Your site will be live in 1-2 minutes!

---

### For Mac/Linux Users:

1. **Open Terminal in this folder**
   - Right-click on folder → "New Terminal at Folder"

2. **Run the deployment script**
   ```bash
   ./deploy-mac-linux.sh
   ```

3. **Follow the prompts** (same as Windows above)

---

## Manual Method (If Scripts Don't Work)

Open Command Prompt/Terminal in this folder and run these commands:

```bash
# 1. Initialize git
git init

# 2. Add all files
git add .

# 3. Commit
git commit -m "Initial commit - Investigation Platform"

# 4. Add your GitHub repository
git remote add origin https://github.com/YOUR-USERNAME/investigation-platform.git

# 5. Push to GitHub
git branch -M main
git push -u origin main
```

---

## Troubleshooting

### "git is not recognized"
→ Install Git from: https://git-scm.com

### "Permission denied (publickey)"
→ Use HTTPS URL, not SSH URL
→ GitHub will ask for your username and password

### "Repository not found"
→ Make sure you created the repository on GitHub first
→ Check the URL is correct

---

## After Deployment

Your files are now on GitHub! To make them accessible as a website:

1. Go to: https://github.com/YOUR-USERNAME/investigation-platform
2. Click **Settings**
3. Click **Pages** (left sidebar)
4. Under **Source**, select **"main"** branch
5. Click **Save**
6. Wait 1-2 minutes
7. Your site will be live at: `https://YOUR-USERNAME.github.io/investigation-platform/`

✅ Share this URL with testers!

---

## Need Help?

- GitHub Docs: https://docs.github.com/en/pages
- Git Basics: https://git-scm.com/book/en/v2/Getting-Started-Git-Basics
