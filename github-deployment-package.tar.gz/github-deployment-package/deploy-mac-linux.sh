#!/bin/bash

echo "================================"
echo "GitHub Deployment Script"
echo "================================"
echo ""

# Check if git is installed
if ! command -v git &> /dev/null; then
    echo "ERROR: Git is not installed!"
    echo "Please install Git:"
    echo "  Mac: Install Xcode Command Line Tools"
    echo "  Linux: sudo apt-get install git"
    exit 1
fi

echo "Git is installed. Proceeding..."
echo ""

# Get GitHub repository URL from user
read -p "Enter your GitHub repository URL (e.g., https://github.com/username/investigation-platform.git): " REPO_URL

echo ""
echo "Initializing git repository..."
git init

echo "Adding files..."
git add .

echo "Committing files..."
git commit -m "Initial commit - Investigation Platform Prototype"

echo "Adding remote repository..."
git remote add origin "$REPO_URL"

echo "Pushing to GitHub..."
git branch -M main
git push -u origin main

echo ""
echo "================================"
echo "✅ Deployment Complete!"
echo "================================"
echo ""
echo "Your prototype is now on GitHub!"
echo ""
echo "To enable GitHub Pages:"
echo "1. Go to your repository on GitHub"
echo "2. Click Settings"
echo "3. Click Pages (left sidebar)"
echo "4. Under 'Source', select 'main' branch"
echo "5. Click Save"
echo "6. Wait 1-2 minutes"
echo "7. Your site will be live at: https://username.github.io/investigation-platform/"
echo ""
